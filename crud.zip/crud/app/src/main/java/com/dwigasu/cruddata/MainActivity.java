package com.dwigasu.cruddata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    Button btnlihat, btninput, btninformasi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnlihat = findViewById(R.id.btlihat);
        btninput = findViewById(R.id.bttambah);
        btninformasi = findViewById(R.id.btinformasi);

        btnlihat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, lihatdata.class);
                startActivity(a);
            }
        });

        btninput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, TambahData.class);
                startActivity(a);
            }
        });
    }
}