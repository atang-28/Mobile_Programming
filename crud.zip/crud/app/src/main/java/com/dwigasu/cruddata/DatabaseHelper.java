package com.dwigasu.cruddata;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "dataBarang.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //untuk membuat tabel dengan nama biodata
        String sql = "create table detail_barang " +
                "(id_Brg integer primary key, nama text null, kategori text null, stok integer null, harga integer null);";
        Log.d("Data", "onCreate: " + sql);
        //menjalankan query / sql
        db.execSQL(sql);
        //untuk insert data ke tabel biodata
        sql = "INSERT INTO detail_barang (id_Brg, nama, kategori, stok, harga) VALUES (1, 'Redmi 9a', 'Gadget', 89, 2000000);";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {

    }
}
