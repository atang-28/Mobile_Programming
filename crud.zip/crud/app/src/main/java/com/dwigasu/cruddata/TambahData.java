package com.dwigasu.cruddata;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TambahData extends AppCompatActivity {
    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextID, editTextNama, editTextMerk, editTextHarga, editTextStok;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_data);

        dbHelper = new DatabaseHelper(this);

        editTextID = findViewById(R.id.edit_text_id);
        editTextNama = findViewById(R.id.edit_text_nama);
        editTextMerk = findViewById(R.id.edit_text_merk);
        editTextHarga = findViewById(R.id.edit_text_harga);
        editTextStok = findViewById(R.id.edit_text_stok);

        buttonSimpan = findViewById(R.id.button_simpan);

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                edit = editTextID.getText().toString();
                edit = editTextNama.getText().toString();
                edit = editTextMerk.getText().toString();
                edit = editTextHarga.getText().toString();
                edit = editTextStok.getText().toString();

                if (edit.isEmpty()) { //cek text box kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else {                           //nama field di tabel
                    db.execSQL("insert into detail_barang (id_Brg, nama, merk, harga, stok) values('" +
                            editTextID.getText().toString() + "','" +
                            editTextNama.getText().toString() +"','" +
                            editTextMerk.getText().toString() + "','" +
                            editTextHarga.getText().toString() + "','" +
                            editTextStok.getText().toString() + "')");
                    Toast.makeText(getApplicationContext(), "Data Tersimpan...", Toast.LENGTH_SHORT).show();
                    finish();
                }
                lihatdata.dm.refreshList();
            }
        });

    }
}