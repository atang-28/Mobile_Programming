package com.dwigasu.cruddata;

//import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class DetailDataMahasiswa extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    TextView txtID, txtnama, txtMerk, txtStok, txtHarga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data_mahasiswa);

        dbHelper = new DatabaseHelper(this);

        txtID = findViewById(R.id.text_ID);
        txtnama = findViewById(R.id.text_nama);
        txtMerk = findViewById(R.id.text_merk);
        txtStok = findViewById(R.id.text_stok);
        txtHarga = findViewById(R.id.text_harga);
        //koneksi ke database
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        //melakukan query ke db/tabel
        cursor = db.rawQuery("SELECT * FROM detail_barang WHERE nama = '" + getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            txtID.setText(cursor.getString(0).toString());
            txtnama.setText(cursor.getString(1).toString());
            txtMerk.setText(cursor.getString(2).toString());
            txtStok.setText(cursor.getString(3).toString());
            txtHarga.setText(cursor.getString(4).toString());
        }
    }
}