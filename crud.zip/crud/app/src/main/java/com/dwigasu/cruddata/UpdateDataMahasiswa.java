package com.dwigasu.cruddata;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateDataMahasiswa extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button buttonSimpan;
    EditText editTextId, editTextNama, editTextHarga, editTextStok;
    Spinner editTextMerk;
    String edit;
    //TextView textViewNomor, textViewNama, textViewTanggalLahir, textViewJenisKelamin, textViewAlamat;
    lihatdata lh = new lihatdata();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data_mahasiswa);

        dbHelper = new DatabaseHelper(this);

        editTextId = findViewById(R.id.edit_text_ID);
        editTextNama = findViewById(R.id.edit_text_nama);
        editTextMerk = findViewById(R.id.edit_text_merk);
        editTextHarga = findViewById(R.id.edit_text_harga);
        editTextStok = findViewById(R.id.edit_text_stok);

//        textViewNomor = findViewById(R.id.text_view_nomor);
//        textViewNama = findViewById(R.id.text_view_nama);
//        textViewTanggalLahir = findViewById(R.id.text_view_tanggal_lahir);
//        textViewJenisKelamin = findViewById(R.id.text_view_jenis_kelamin);
//        textViewAlamat = findViewById(R.id.text_view_alamat);

        buttonSimpan = findViewById(R.id.button_simpan);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        //query untuk mengambil data dari tabel berdasarkan nama
        cursor = db.rawQuery("SELECT * FROM detail_barang WHERE nama = '" + getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            editTextId.setText(cursor.getString(0).toString());
            editTextNama.setText(cursor.getString(1).toString());
            String kategori = cursor.getString(2).toString();
            int selectedIndex = ArrayAdapter.createFromResource(this, R.array.kategori, android.R.layout.simple_spinner_item).getPosition(kategori);
            editTextMerk.setSelection(selectedIndex);
            editTextHarga.setText(cursor.getString(3).toString());
            editTextStok.setText(cursor.getString(4).toString());

        }

        buttonSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                edit = editTextId.getText().toString();
                edit = editTextNama.getText().toString();
                edit = editTextMerk.getSelectedItem().toString();
                edit = editTextHarga.getText().toString();
                edit = editTextStok.getText().toString();

                if (edit.isEmpty()) { //untuk tek kolom kosong
                    Toast.makeText(getApplicationContext(), "Kolom tidak boleh kosong...", Toast.LENGTH_SHORT).show();
                } else { //query untuk melakukan update data di tabel
                    db.execSQL("update detail_barang set nama='" +
                            editTextNama.getText().toString() + "', kategori='" +
                            editTextMerk.getSelectedItem().toString() + "', harga='" +
                            editTextHarga.getText().toString() + "', stok='" +
                            editTextStok.getText().toString() + "' where id_Brg='" +
                            editTextId.getText().toString() + "'");

                    Toast.makeText(getApplicationContext(), "Perubahan Tersimpan...", Toast.LENGTH_LONG).show();
                    finish();
                }
                //refresh();
                lihatdata.dm.refreshList();
                //lh.refreshList();

            }
        });
    }

  }